from flask import Flask,render_template,request,jsonify
# from flask_pymongo import PyMongo
from util.sql_nosql import query_mongo,query_coins
import time
app = Flask(__name__)
# app.config["MONGO_URI"] = "mongodb://localhost:27017/yourdatabase"
# mongo = PyMongo(app)
# Access the homepage
@app.route('/')
def index():
    # return "hellowrd"
    return render_template("demo.html")
# Click the button to search for news and articles
@app.route('/search', methods=['POST', 'GET'])
def search():
    start_time = time.time()
    if request.method == "POST":
        data = request.form.to_dict()  # Get the value input by the frontend
        for i in data.keys():
            new_dict = eval(i)
        print(new_dict)
        res = query_mongo(new_dict)
        return jsonify(res)
    data = ""
    res = query_mongo()
    return jsonify(res)
# Click the button to search for cryptocurrency prices
@app.route('/searchcoins', methods=['POST', 'GET'])
def searchcoins():
    start_time = time.time()
    if request.method == "POST":
        data = request.form.to_dict()  # Get the value input by the frontend
        for i in data.keys():
            new_dict = eval(i)
        print(new_dict)
        res = query_coins(new_dict)
        return jsonify(res)
    data = ""
    res = query_coins()
    return jsonify(res)

if __name__ == '__main__':
    app.run(debug=True)
