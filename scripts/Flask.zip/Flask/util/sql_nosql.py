from flask import session, request
from pymongo import MongoClient
from .sqltable import select_sql
import math
import time
from datetime import datetime


def query_mongo(data):
    # Connect to MongoDB
    start_time = time.time()
    client = MongoClient('mongodb://localhost:27017')

    # Select the database
    db = client['GROUP8_NEWS']

    # Select the collection (similar to tables in SQL)
    collection = db['Group8']
    # print(collection[:300])
    currentPage = request.args.get("page", 1)  # Retrieve the page number requested by the frontend, defaulting to the first page if not specified
    pageSize = 10  # The pagination page size is set to 10, meaning pagination will be displayed after exceeding 10 items
  
    keyword = data.get('keyword')
    startdate = data.get('startdate')
    enddate = data.get('enddate')
    currentPage = data.get('page',1)


    key_to_match = "tickers" 
    value_to_match = keyword # Use the $elemMatch operator to query documents containing a specific key-value pair
    query = {"data": {"$elemMatch": {key_to_match: value_to_match}}} 

    results = collection.find(query) # Iterate through and print the query results 
    # W = open("test","w",encoding="utf-8")
    print(keyword)
    tmp_list = []
    startdate = datetime.strptime(startdate, "%Y-%m-%d")
    enddate = datetime.strptime(enddate, "%Y-%m-%d")
    for j in results: 
        for i in j['data']:
            tickers =i['tickers'][0]
            item = i
    
            if tickers == keyword:
                date_obj = datetime.strptime(item['date'].split(",")[-1].split("-")[0].strip(), "%d %b %Y %H:%M:%S")


                if date_obj>=startdate and date_obj<=enddate:
                    tmp_list.append([item['date'],item['news_url'],item['title'],item['type'],item['sentiment']])

    total = len(tmp_list)
    # Calculate the total number of items and the number of pages
    totalItems = total
    totalPages = math.ceil(total / pageSize)
    print(currentPage)
    print((int(currentPage) - 1) * pageSize,(int(currentPage)) * pageSize)

    end_time = time.time()
    t = end_time - start_time
    t = "{:.2f}".format(t)
    print(t,"|bbbbbbbbbbbbb")
    result = {
        "status": 200,
        "data": {
            "detail": tmp_list[(int(currentPage) - 1) * pageSize:(int(currentPage)) * pageSize]
        },
        "pagination": {
            "totalItemsnews": totalItems,
            "totalPagesnews": totalPages,


        },
        "t":t
    }
    return result


def query_coins(data):
    start_time = time.time()

    pageSize = 10  # The pagination page size is set to 10, meaning pagination will be displayed after exceeding 10 items

    keyword = data.get('keyword')
    name = data.get('name') 
    startdate = data.get('startdate')
    enddate = data.get('enddate')
    currentPage = data.get('page', 1)

    def not_empty(var):
        return var is not None and var != ""
    ##### Check coins price
    condition_str = "1"
    if not_empty(keyword):
        condition_str = "symbol = '{}'".format(keyword)
    if not_empty(name):
        condition_str = "name = '{}'".format(name)
    if not_empty(name) and not_empty(keyword):
        condition_str = "(symbol = '{}' AND name = '{}')".format(keyword, name)
    
    sql = """ select symbol,name,to_char(quote_timestamp,'yyyy-mm-dd HH24:MI:SS') ,volume_24h,price from coins where {} and quote_timestamp>'{}' and quote_timestamp < '{}'  LIMIT {} OFFSET {};""".format(
        condition_str, startdate, enddate,pageSize, (int(currentPage) - 1) * pageSize)
    sql1 = """ select count(*) from coins where {}  and quote_timestamp>'{}' and quote_timestamp < '{}'""".format(
        condition_str, startdate, enddate)
    try:
        data = select_sql(sql)
        total = select_sql(sql1)[0][0]
    except Exception as e:
        print("Exception:", e)
        data = []
    print(data)
    totalItems = total
    totalPages = math.ceil(total / pageSize)
    end_time = time.time()
    t= end_time -start_time
    t = "{:.2f}".format(t)
    print(t,"|bbbbbbbbbbbbb")

    result = {
        "status": 200,
        "data": {
            "detail": data
        },
        "pagination": {
            "totalItemsnews": totalItems,
            "totalPagesnews": totalPages,

        },
        "t":t
    }
    return result

