# from pymysql import *
import psycopg2


def select_sql(sql):
    # mysql database
    # conn = connect(host='110.41.184.108', port=3306, user='root', password='123456', database='demo')


    # Configure PostgreSQL database connection parameters
    conn_params = {
        "dbname": "GROUP8_COINS",
        "user": "postgres",
        "password": "123",
        "host": "localhost",
        "port":"5432"
    }

    # Connect to the database
    conn = psycopg2.connect(**conn_params)
    print(sql)
    cs1 = conn.cursor()
    try:
        cs1.execute(sql)
        res = cs1.fetchall()
        print("aaa",res)
        return res
    except Exception as e:
        print(e, sql)
        return False



if __name__ == '__main__':  # Debugging, no need to worry about it.
    pass

"""
CREATE DATABASE  price

CREATE TABLE coins (
       circulating_supply FLOAT,
    market_cap FLOAT,
    percent_change_1h FLOAT,
    percent_change_24h FLOAT,
    percent_change_30d FLOAT,
    percent_change_7d FLOAT,
    price FLOAT,
    timestamp TIMESTAMP,
    total_supply FLOAT,
    volume_24h FLOAT,
    quote_timestamp TIMESTAMP,
    id integer,
    name VARCHAR(100),
    symbol VARCHAR(100),
    is_active integer,
    unix_timestamp integer,
    ma_7d FLOAT,
    PRIMARY KEY (quote_timestamp, name)
   );
"""
